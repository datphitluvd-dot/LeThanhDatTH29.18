package client;

import java.io.*;
import java.net.*;

public class ChatClient {

    Socket socket;
    BufferedReader in;
    public PrintWriter out;

    public ChatClient(){

        try{

            socket = new Socket("26.6.251.221",5000);

            in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));

            out = new PrintWriter(socket.getOutputStream(),true);

        }catch(Exception e){
            e.printStackTrace();
        }

    }

}