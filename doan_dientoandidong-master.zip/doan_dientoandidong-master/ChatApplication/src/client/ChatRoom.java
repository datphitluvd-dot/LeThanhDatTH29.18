package client;

import database.DBConnection;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ChatRoom extends JFrame {

    private JPanel messagesPanel;          // Panel chứa các tin nhắn
    private JScrollPane scrollPane;
    private JTextField messageField;
    private JButton sendButton;
    private JLabel avatarLabel;

    private ChatClient client;
    private String username;

    public ChatRoom(ChatClient client, String username) {
        this.client = client;
        this.username = username;

        // Thiết lập Look and Feel
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // Fallback
        }

        initUI();
        client.out.println(username);
        receiveMessages();
        loadHistory();

        sendButton.addActionListener(e -> sendMessage());
        messageField.addActionListener(e -> sendMessage());

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                closeConnection();
                dispose();
                System.exit(0);
            }
        });
    }

    private void initUI() {
        setTitle("Mini Chat - " + username);
        setSize(450, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Background panel (giữ nguyên)
        BackgroundPanel backgroundPanel = new BackgroundPanel();
        backgroundPanel.setLayout(new BorderLayout());

        // ===== Thanh tiêu đề =====
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(0, 0, 0, 150));
        topPanel.setBorder(new EmptyBorder(10, 15, 10, 15));
        topPanel.setOpaque(false);

        avatarLabel = new JLabel();
        avatarLabel.setPreferredSize(new Dimension(40, 40));
        avatarLabel.setOpaque(true);
        avatarLabel.setBackground(new Color(255, 255, 255, 200));
        avatarLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        avatarLabel.setHorizontalAlignment(SwingConstants.CENTER);
        avatarLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        avatarLabel.setText(username.substring(0, 1).toUpperCase());
        avatarLabel.setForeground(new Color(70, 130, 180));

        JLabel nameLabel = new JLabel(username);
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setBorder(new EmptyBorder(0, 10, 0, 0));

        topPanel.add(avatarLabel, BorderLayout.WEST);
        topPanel.add(nameLabel, BorderLayout.CENTER);

        // ===== Khu vực chat (JPanel thay cho JTextArea) =====
        messagesPanel = new JPanel();
        messagesPanel.setLayout(new BoxLayout(messagesPanel, BoxLayout.Y_AXIS));
        messagesPanel.setBackground(new Color(255, 255, 255, 220));
        messagesPanel.setOpaque(false);

        scrollPane = new JScrollPane(messagesPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getViewport().setBackground(new Color(0, 0, 0, 0));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        // ===== Thanh nhập tin nhắn =====
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(new Color(0, 0, 0, 100));
        bottomPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        bottomPanel.setOpaque(false);

        messageField = new JTextField();
        messageField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        messageField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255, 255, 255, 100), 1, true),
                new EmptyBorder(8, 10, 8, 10)
        ));
        messageField.setBackground(new Color(255, 255, 255, 200));
        messageField.setForeground(Color.DARK_GRAY);
        messageField.setCaretColor(new Color(70, 130, 180));
        messageField.setOpaque(false);

        // Placeholder
        messageField.setText("Nhập tin nhắn...");
        messageField.setForeground(Color.GRAY);
        messageField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (messageField.getText().equals("Nhập tin nhắn...")) {
                    messageField.setText("");
                    messageField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (messageField.getText().isEmpty()) {
                    messageField.setText("Nhập tin nhắn...");
                    messageField.setForeground(Color.GRAY);
                }
            }
        });

        sendButton = new JButton("Gửi");
        sendButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        sendButton.setBackground(new Color(70, 130, 180, 200));
        sendButton.setForeground(Color.WHITE);
        sendButton.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        sendButton.setFocusPainted(false);
        sendButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        sendButton.setOpaque(false);

        sendButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                sendButton.setBackground(new Color(100, 150, 200, 200));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                sendButton.setBackground(new Color(70, 130, 180, 200));
            }
        });

        bottomPanel.add(messageField, BorderLayout.CENTER);
        bottomPanel.add(Box.createRigidArea(new Dimension(10, 0)), BorderLayout.EAST);
        bottomPanel.add(sendButton, BorderLayout.EAST);

        backgroundPanel.add(topPanel, BorderLayout.NORTH);
        backgroundPanel.add(scrollPane, BorderLayout.CENTER);
        backgroundPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(backgroundPanel);
        setVisible(true);
    }

    // Lớp BackgroundPanel (giữ nguyên)
    class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel() {
            try {
                backgroundImage = Toolkit.getDefaultToolkit().getImage("background.jpg");
            } catch (Exception e) {}
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            } else {
                Graphics2D g2d = (Graphics2D) g;
                int w = getWidth();
                int h = getHeight();
                Color color1 = new Color(70, 130, 180);
                Color color2 = new Color(255, 255, 255);
                GradientPaint gp = new GradientPaint(0, 0, color1, w, h, color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, w, h);
            }
        }
    }

    // Gửi tin nhắn
    private void sendMessage() {
        String message = messageField.getText().trim();
        if (message.isEmpty() || message.equals("Nhập tin nhắn...")) {
            return;
        }
        client.out.println(message);
        messageField.setText("");
        messageField.setForeground(Color.BLACK);
    }

    // Nhận tin nhắn từ server
    private void receiveMessages() {
        new Thread(() -> {
            try {
                String incoming;
                while ((incoming = client.in.readLine()) != null) {
                    final String msg = incoming;
                    SwingUtilities.invokeLater(() -> addMessage(msg));
                }
                SwingUtilities.invokeLater(() -> {
                    addSystemMessage("Kết nối tới server đã đóng.");
                    messageField.setEnabled(false);
                    sendButton.setEnabled(false);
                });
            } catch (IOException e) {
                SwingUtilities.invokeLater(() -> {
                    addSystemMessage("Mất kết nối tới server.");
                    messageField.setEnabled(false);
                    sendButton.setEnabled(false);
                });
            }
        }).start();
    }

    // Thêm tin nhắn dạng bong bóng
    private void addMessage(String fullMessage) {
        // Giả sử server gửi: "username: nội dung"
        int colonIndex = fullMessage.indexOf(": ");
        if (colonIndex == -1) {
            addSystemMessage(fullMessage); // Không đúng định dạng, xem như hệ thống
            return;
        }

        String sender = fullMessage.substring(0, colonIndex);
        String content = fullMessage.substring(colonIndex + 2); // Bỏ ": "

        boolean isMe = sender.equals(username);

        // Panel chứa bong bóng chat
        JPanel bubblePanel = new JPanel(new BorderLayout());
        bubblePanel.setOpaque(false);
        bubblePanel.setBorder(new EmptyBorder(5, 10, 5, 10));

        // Panel chứa nội dung (để căn lề)
        JPanel messageBubble = new JPanel(new FlowLayout(isMe ? FlowLayout.RIGHT : FlowLayout.LEFT, 0, 0));
        messageBubble.setOpaque(false);

        // Label hiển thị tin nhắn (dùng HTML để tạo màu nền và bo góc)
        String bgColor = isMe ? "#0084ff" : "#e4e6eb";
        String textColor = isMe ? "white" : "black";
        String alignment = isMe ? "right" : "left";

        JLabel messageLabel = new JLabel(
            "<html><div style='background-color: " + bgColor + "; " +
            "color: " + textColor + "; " +
            "padding: 8px 12px; " +
            "border-radius: 18px; " +
            "max-width: 250px; " +
            "word-wrap: break-word; " +
            "display: inline-block; " +
            "text-align: " + alignment + ";'>" +
            content +
            "</div></html>"
        );
        messageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        messageBubble.add(messageLabel);

        if (isMe) {
            bubblePanel.add(messageBubble, BorderLayout.EAST);
        } else {
            bubblePanel.add(messageBubble, BorderLayout.WEST);
        }

        messagesPanel.add(bubblePanel);
        messagesPanel.revalidate();
        messagesPanel.repaint();

        // Cuộn xuống cuối
        SwingUtilities.invokeLater(() -> {
            JScrollBar vertical = scrollPane.getVerticalScrollBar();
            vertical.setValue(vertical.getMaximum());
        });
    }

    // Thêm tin nhắn hệ thống
    private void addSystemMessage(String sysMsg) {
        JPanel sysPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        sysPanel.setOpaque(false);
        sysPanel.setBorder(new EmptyBorder(5, 10, 5, 10));

        JLabel sysLabel = new JLabel(sysMsg);
        sysLabel.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        sysLabel.setForeground(Color.GRAY);

        sysPanel.add(sysLabel);
        messagesPanel.add(sysPanel);
        messagesPanel.revalidate();
        messagesPanel.repaint();

        SwingUtilities.invokeLater(() -> {
            JScrollBar vertical = scrollPane.getVerticalScrollBar();
            vertical.setValue(vertical.getMaximum());
        });
    }

    // Load lịch sử từ database
    private void loadHistory() {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT username, message FROM messages ORDER BY id ASC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String sender = rs.getString("username");
                String msg = rs.getString("message");
                addMessage(sender + ": " + msg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Đóng kết nối socket
    private void closeConnection() {
        try {
            if (client != null && client.socket != null && !client.socket.isClosed()) {
                client.socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}