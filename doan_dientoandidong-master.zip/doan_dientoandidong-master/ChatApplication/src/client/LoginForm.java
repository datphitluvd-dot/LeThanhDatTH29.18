package client;

import database.DBConnection;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class LoginForm extends JFrame {

    private JTextField userField;
    private JPasswordField passField;
    private JButton loginBtn;
    private JButton registerBtn;
    private JCheckBox showPassCheck;

    public LoginForm() {
        initComponents();
        setupLayout();
        addEventHandlers();
        setTitle("Đăng nhập - Chat Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    private void initComponents() {
        userField = new JTextField(15);
        passField = new JPasswordField(15);
        loginBtn = new JButton("Đăng nhập");
        registerBtn = new JButton("Đăng ký");
        showPassCheck = new JCheckBox("Hiện mật khẩu");

        Font font = new Font("Segoe UI", Font.PLAIN, 14);
        userField.setFont(font);
        passField.setFont(font);
        loginBtn.setFont(font);
        registerBtn.setFont(font);
        showPassCheck.setFont(font);

        loginBtn.setBackground(new Color(70, 130, 180));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);
        registerBtn.setBackground(new Color(60, 179, 113));
        registerBtn.setForeground(Color.WHITE);
        registerBtn.setFocusPainted(false);
    }

    private void setupLayout() {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Tạo các JLabel (không lưu làm field vì chỉ dùng 1 lần)
        JLabel userLabel = new JLabel("Tên đăng nhập:");
        JLabel passLabel = new JLabel("Mật khẩu:");
        userLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        passLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));

        // THÊM TẤT CẢ COMPONENT VÀO PANEL
        panel.add(userLabel);
        panel.add(userField);
        panel.add(passLabel);
        panel.add(passField);
        panel.add(showPassCheck);
        panel.add(loginBtn);
        panel.add(registerBtn);

        // Thiết lập GroupLayout
        GroupLayout layout = new GroupLayout(panel);
        panel.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        // Horizontal group
        GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
        hGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                .addComponent(userLabel)
                .addComponent(passLabel));
        hGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(userField)
                .addComponent(passField)
                .addComponent(showPassCheck)
                .addGroup(layout.createSequentialGroup()
                        .addComponent(loginBtn)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(registerBtn)));
        layout.setHorizontalGroup(hGroup);

        // Vertical group
        GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(userLabel)
                .addComponent(userField));
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(passLabel)
                .addComponent(passField));
        vGroup.addComponent(showPassCheck);
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(loginBtn)
                .addComponent(registerBtn));
        layout.setVerticalGroup(vGroup);

        add(panel);
    }

    private void addEventHandlers() {
        showPassCheck.addActionListener(e -> {
            passField.setEchoChar(showPassCheck.isSelected() ? (char) 0 : '•');
        });

        loginBtn.addActionListener(e -> login());
        registerBtn.addActionListener(e -> {
            new RegisterForm();
            dispose();
        });

        passField.addActionListener(e -> login());

        getRootPane().registerKeyboardAction(e -> System.exit(0),
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
                JComponent.WHEN_IN_FOCUSED_WINDOW);
    }

    private void login() {
        String username = userField.getText().trim();
        String password = new String(passField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu",
                    "Thiếu thông tin", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ChatClient client = new ChatClient();
                ChatRoom chat = new ChatRoom(client, username);
                chat.setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Sai tên đăng nhập hoặc mật khẩu",
                        "Đăng nhập thất bại", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Lỗi cơ sở dữ liệu: " + e.getMessage(),
                    "Lỗi hệ thống", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        SwingUtilities.invokeLater(() -> new LoginForm());
    }
}