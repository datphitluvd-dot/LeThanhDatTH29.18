package client;

import database.DBConnection;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class RegisterForm extends JFrame {

    private JTextField userField;
    private JPasswordField passField;
    private JPasswordField confirmField;
    private JButton registerBtn;
    private JButton cancelBtn;
    private JCheckBox showPassCheck;

    public RegisterForm() {
        initComponents();
        setupLayout();
        addEventHandlers();
        setTitle("Đăng ký tài khoản - Chat Application");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(450, 320);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    private void initComponents() {
        userField = new JTextField(15);
        passField = new JPasswordField(15);
        confirmField = new JPasswordField(15);
        registerBtn = new JButton("Đăng ký");
        cancelBtn = new JButton("Hủy");
        showPassCheck = new JCheckBox("Hiện mật khẩu");

        Font font = new Font("Segoe UI", Font.PLAIN, 14);
        userField.setFont(font);
        passField.setFont(font);
        confirmField.setFont(font);
        registerBtn.setFont(font);
        cancelBtn.setFont(font);
        showPassCheck.setFont(font);

        registerBtn.setBackground(new Color(60, 179, 113));
        registerBtn.setForeground(Color.WHITE);
        registerBtn.setFocusPainted(false);
        cancelBtn.setBackground(new Color(220, 20, 60));
        cancelBtn.setForeground(Color.WHITE);
        cancelBtn.setFocusPainted(false);
    }

    private void setupLayout() {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Tạo JLabel
        JLabel userLabel = new JLabel("Tên đăng nhập:");
        JLabel passLabel = new JLabel("Mật khẩu:");
        JLabel confirmLabel = new JLabel("Xác nhận mật khẩu:");
        userLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        passLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        confirmLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));

        // THÊM TẤT CẢ COMPONENT VÀO PANEL
        panel.add(userLabel);
        panel.add(userField);
        panel.add(passLabel);
        panel.add(passField);
        panel.add(confirmLabel);
        panel.add(confirmField);
        panel.add(showPassCheck);
        panel.add(registerBtn);
        panel.add(cancelBtn);

        GroupLayout layout = new GroupLayout(panel);
        panel.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        // Horizontal group
        GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
        hGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                .addComponent(userLabel)
                .addComponent(passLabel)
                .addComponent(confirmLabel));
        hGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(userField)
                .addComponent(passField)
                .addComponent(confirmField)
                .addComponent(showPassCheck)
                .addGroup(layout.createSequentialGroup()
                        .addComponent(registerBtn)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cancelBtn)));
        layout.setHorizontalGroup(hGroup);

        // Vertical group
        GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(userLabel)
                .addComponent(userField));
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(passLabel)
                .addComponent(passField));
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(confirmLabel)
                .addComponent(confirmField));
        vGroup.addComponent(showPassCheck);
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(registerBtn)
                .addComponent(cancelBtn));
        layout.setVerticalGroup(vGroup);

        add(panel);
    }

    private void addEventHandlers() {
        showPassCheck.addActionListener(e -> {
            char echo = showPassCheck.isSelected() ? (char) 0 : '•';
            passField.setEchoChar(echo);
            confirmField.setEchoChar(echo);
        });

        registerBtn.addActionListener(e -> register());
        confirmField.addActionListener(e -> register());
        cancelBtn.addActionListener(e -> dispose());

        getRootPane().registerKeyboardAction(e -> dispose(),
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
                JComponent.WHEN_IN_FOCUSED_WINDOW);
    }

    private void register() {
        String username = userField.getText().trim();
        String password = new String(passField.getPassword()).trim();
        String confirm = new String(confirmField.getPassword()).trim();

        if (username.isEmpty()) {
            showError("Vui lòng nhập tên đăng nhập.");
            userField.requestFocus();
            return;
        }
        if (password.isEmpty()) {
            showError("Vui lòng nhập mật khẩu.");
            passField.requestFocus();
            return;
        }
        if (confirm.isEmpty()) {
            showError("Vui lòng xác nhận mật khẩu.");
            confirmField.requestFocus();
            return;
        }
        if (username.length() < 3 || username.length() > 20) {
            showError("Tên đăng nhập phải từ 3 đến 20 ký tự.");
            userField.requestFocus();
            return;
        }
        if (password.length() < 6) {
            showError("Mật khẩu phải có ít nhất 6 ký tự.");
            passField.requestFocus();
            return;
        }
        if (!password.equals(confirm)) {
            showError("Mật khẩu xác nhận không khớp.");
            confirmField.requestFocus();
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            // Kiểm tra username đã tồn tại
            String checkSql = "SELECT username FROM users WHERE username = ?";
            PreparedStatement checkPs = conn.prepareStatement(checkSql);
            checkPs.setString(1, username);
            ResultSet rs = checkPs.executeQuery();
            if (rs.next()) {
                showError("Tên đăng nhập đã tồn tại.");
                userField.requestFocus();
                return;
            }

            // Thêm user mới
            String insertSql = "INSERT INTO users(username, password) VALUES(?, ?)";
            PreparedStatement insertPs = conn.prepareStatement(insertSql);
            insertPs.setString(1, username);
            insertPs.setString(2, password); // Nhớ mã hóa trong thực tế

            int affected = insertPs.executeUpdate();
            if (affected > 0) {
                JOptionPane.showMessageDialog(this,
                        "Đăng ký thành công!",
                        "Thành công", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                showError("Đăng ký thất bại.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showError("Lỗi cơ sở dữ liệu: " + e.getMessage());
        }
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Lỗi", JOptionPane.ERROR_MESSAGE);
    }
}