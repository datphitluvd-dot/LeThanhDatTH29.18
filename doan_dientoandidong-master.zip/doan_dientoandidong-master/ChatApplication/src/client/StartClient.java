package client;

public class StartClient {

    public static void main(String[] args) {

        LoginForm loginForm = new LoginForm();

    }

}