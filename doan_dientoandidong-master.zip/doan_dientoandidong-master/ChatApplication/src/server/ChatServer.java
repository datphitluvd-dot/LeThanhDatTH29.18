package server;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class ChatServer {

    static Vector<ClientHandler> clients = new Vector<>();

    public static void main(String[] args) {

        try {

            ServerSocket server = new ServerSocket(5000);

            System.out.println("Server started...");

            while(true){

                Socket socket = server.accept();

                ClientHandler client = new ClientHandler(socket);

                clients.add(client);

                new Thread(client).start();

            }

        } catch(Exception e){
            e.printStackTrace();
        }

    }

}