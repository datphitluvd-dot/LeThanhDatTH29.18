package server;

import database.DBConnection;
import java.net.*;
import java.io.*;
import java.sql.*;

public class ClientHandler implements Runnable {

    Socket socket;
    BufferedReader in;
    PrintWriter out;
    String username;

    public ClientHandler(Socket socket){
        this.socket = socket;
        
        try{
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void run(){

        try{

            username = in.readLine();
            System.out.println(username + " joined");

            String msg;

            while((msg = in.readLine()) != null){

                String fullMsg = username + ": " + msg;

                saveMessage(username, msg); // lưu DB

                // gửi cho tất cả client
                for(ClientHandler c : ChatServer.clients){
                    c.out.println(fullMsg);
                }

            }

        }catch(Exception e){
            System.out.println("User disconnected");
        }
    }

    // lưu tin nhắn vào database
    public void saveMessage(String username, String message){

        try{

            Connection conn = DBConnection.getConnection();

            String sql = "INSERT INTO messages(username,message) VALUES(?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, username);
            ps.setString(2, message);

            ps.executeUpdate();

        }catch(Exception e){
            e.printStackTrace();
        }

    }
}