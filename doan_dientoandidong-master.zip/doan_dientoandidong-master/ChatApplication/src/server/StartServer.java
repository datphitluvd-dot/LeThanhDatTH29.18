package server;

public class StartServer {

    public static void main(String[] args) {

        try {

            ChatServer.main(args);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}